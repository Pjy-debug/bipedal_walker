To register the envs, run:
```
pip install -e .
```
